package poke;

public class PokeELECTRIK extends Pokemon {
	private int pattes;
	private int nbAiles;
	private double intensite;
	
	
public PokeELECTRIK(String name, double height, double weight, double pointDeVie, double pointCombat,PokType Ptype,int Ppattes,int ailes,double inten) {
	super(name, height, weight, pointDeVie, pointCombat, Ptype);
		this.pattes=Ppattes;
		this.nbAiles=ailes;
		this.intensite=inten;
	}
public double calculerVitesse() {
	double vitesse=(pattes+nbAiles)*intensite*0.05;
	return vitesse;
}
public void attaquer(Pokemon p) {
	switch(p.getType()){
	case FEU:					//*2 pc against FEU    //0.5 against PLANTE et EAU
		p.setPv(p.getPv()-this.getPc()*1);
		this.setPv(this.getPv()-p.getPc()*0.5);
		break;
	case PLANTE:
		p.setPv(p.getPv()-this.getPc()*0.5);
		this.setPv(this.getPv()-p.getPc()*2);
		break;
	case EAU:
		p.setPv(p.getPv()-this.getPc()*2);
		this.setPv(this.getPv()-p.getPc()*1);
		break;
	case ELECTRIK:
		p.setPv(p.getPv()-this.getPc()*0.5);
		this.setPv(this.getPv()-p.getPc()*0.5);
		break;
	}
	
}
}
