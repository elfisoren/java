package poke;

public abstract class Pokemon {
	private String nom;
	private double taille;
	private double poids;
	private double pv;
	private double pc;
	private PokType type;

public Pokemon(String name,double height,double weight,double pointDeVie,double pointCombat,PokType Ptype) {
	this.nom=name;
	this.taille=height;
	this.poids=weight;
	this.pv=pointDeVie;
	this.pc=pointCombat;
	this.type=Ptype;
}
public boolean estVivant() {
	if (this.pv>0) {
		return true;
	}else {
		return false;
	}
}
public abstract void attaquer(Pokemon p);


public String toString() {
	return("Information de : "+nom+"\ntaille : "+taille+"m\npoids : "+poids+"kg\n pv :"+pv+"\npc : "+pc+"\ntype : "+type+"");
}


















public String getNom() {
	return nom;
}
public void setNom(String nom) {
	this.nom = nom;
}
public double getTaille() {
	return taille;
}
public void setTaille(double taille) {
	this.taille = taille;
}
public double getPoids() {
	return poids;
}
public void setPoids(double poids) {
	this.poids = poids;
}
public double getPv() {
	return pv;
}
public void setPv(double pv) {
	this.pv = pv;
}
public double getPc() {
	return pc;
}
public void setPc(double pc) {
	this.pc = pc;
}
public PokType getType() {
	return type;
}
public void setType(PokType type) {
	this.type = type;
}
}
