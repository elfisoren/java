package poke;

public enum PokType {
	ACIER,
	BIRD,
	COMBAT,
	DRAGON,
	EAU,
	ELECTRIK,
	FEE,
	FEU,
	GLACE,
	inconnu,
	INSECTE,
	NORMAL,
	OBSCUR,
	PLANTE,
	POISON,
	PSY,
	ROCHE,
	SOL,
	SPECTRE,
	TENEBRES,
	VOL;	
}
