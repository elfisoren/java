package poke;

public class PokePLANTE extends Pokemon {

public PokePLANTE(String name, double height, double weight, double pointDeVie, double pointCombat, PokType Ptype) {
	super(name, height, weight, pointDeVie, pointCombat, Ptype);
		
	}
public double calculerVitesse() {
	double vitesse = 10/(getPoids()*getTaille());
	return vitesse;
}
public void attaquer(Pokemon p) {
	switch(p.getType()){
	case FEU:					//*2 pc against FEU    //0.5 against PLANTE et EAU
		p.setPv(p.getPv()-this.getPc()*0.5);
		this.setPv(this.getPv()-p.getPc()*2);
		break;
	case PLANTE:
		p.setPv(p.getPv()-this.getPc()*0.5);
		this.setPv(this.getPv()-p.getPc()*0.5);
		break;
	case EAU:
		p.setPv(p.getPv()-this.getPc()*1);
		this.setPv(this.getPv()-p.getPc()*0.5);
		break;
	case ELECTRIK:
		p.setPv(p.getPv()-this.getPc()*2);
		this.setPv(this.getPv()-p.getPc()*0.5);
		break;
	}
	
}
}
